
package Models.Nacionalidad;

import Models.BaseDTO;

/**
 *
 * @author hckr
 */
public class NacionalidadDTO extends BaseDTO{

    public NacionalidadDTO(Integer id){
       super(id);
    }
}
