
package Models.Ciudad;

import Models.BaseDTO;

/**
 *
 * @author hckr
 */
public class CiudadDTO  extends BaseDTO{

    public CiudadDTO(Integer id) {
        super(id);
    }
}
